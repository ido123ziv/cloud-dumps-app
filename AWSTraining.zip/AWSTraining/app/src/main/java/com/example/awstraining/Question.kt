package com.example.azure.modules

class Question (q : String, la : ArrayList<Answer>, correct : Int, subject : String) {
    val question: String = q
    var ListOfAnswers: ArrayList<Answer> = shuffleListOfAnswers(la)
    var correctAnswer : Answer = la[correct]
    val subject: String = subject
    val correctID = correct

    private fun isAnsCorrect(a : Answer) : Boolean{
        return a.answer == correctAnswer.answer
    }
    fun isCorrect(i : Int) : Boolean{
        return isAnsCorrect(ListOfAnswers[i])
    }
    private fun shuffleListOfAnswers(la : ArrayList<Answer>) : ArrayList<Answer>{
        var listOfRandoms = la.shuffled()
        var newList = arrayListOf<Answer>()
        for (i in listOfRandoms){
            newList.add(i)
        }
        return newList
    }
}