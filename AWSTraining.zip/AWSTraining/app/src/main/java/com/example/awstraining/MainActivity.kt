package com.example.awstraining

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.support.design.widget.Snackbar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        awsButton.setOnClickListener {
            if (QuestionsInput.text.toString() == "") {
                Snackbar.make(it, "נא להזין את כמות השחקנים", Snackbar.LENGTH_SHORT)
                    .setAction("Action", null).show()
            } else {
                val intent = Intent(this, GameActivity::class.java)

                // TODO pass parameters
                val n = QuestionsInput.text.toString().toInt()
                intent.putExtra(NUM_OF_QUESTIONS, n)

                // Go to activity
                startActivity(intent)
            }
        }
    }

    fun buOBClick(v: View) {
        var intent = Intent(this, GameActivity::class.java)
        startActivity(intent)


    }

}
