package com.example.awstraining

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.example.azure.modules.Answer
import com.example.azure.modules.Question
import kotlinx.android.synthetic.main.activity_game.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.lang.Exception
import java.util.*
import kotlin.collections.ArrayList

class GameActivity : AppCompatActivity() {
    var listOfQuestions = arrayListOf<Question>()
    var myList = arrayListOf<Question>()
    var lastQ = 0
    var listOfCorrect = arrayListOf<Int>()
    private var max = 10
    private var score = 0
    var cond = false
    var arthur = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        listOfQuestions = getDataFromJSON()
        myList = pickQuestions(max)
       // Question2.text= listOfQuestions[0].subject
        printQuestion(myList[lastQ])
        Question2.setOnClickListener { nextQuestion() }
    }
    protected fun GameClickButton(v: View) {
        //Toast.makeText(this,"Exception1",Toast.LENGTH_LONG).show()
        val buSelected = v as Button
        var cellID = 0
        when(buSelected.id){
            R.id.bu1 -> cellID = 0
            R.id.bu2 -> cellID = 1
            R.id.bu3 -> cellID = 2
            R.id.bu4 -> cellID = 3
        }
        playGame(cellID,buSelected)
    }
    fun printCorrect( buSelected : Button){
        buSelected.setBackgroundColor(Color.GREEN)
    }
    fun printInCorrect(buSelected: Button){
        buSelected.setBackgroundColor(Color.RED)
    }
    fun getButtonFromID(i : Int): Button {
        when(i){
            0 -> return bu1
            1 -> return bu2
            2 -> return bu3
            3 -> return bu4
        }
        return bu1
    }
    fun cleanMyMess(){
        printQuestion(myList[lastQ])
        bu1.setBackgroundColor(resources.getColor(R.color.button2))
        bu2.setBackgroundColor(resources.getColor(R.color.button2))
        bu3.setBackgroundColor(resources.getColor(R.color.button2))
        bu4.setBackgroundColor(resources.getColor(R.color.button2))

    }
    fun nextQuestion() {
        if (lastQ < myList.size) {
            if (lastQ < myList.size -1){
                lastQ += 1
                cleanMyMess()
            }
            else{
                lastQ += 1
            }
         }
        else
            printExit()
    }

    fun checkAndPrintCorrectIn(cellID : Int, buSelected : Button){
        var question = myList[lastQ]
        if (question.isCorrect(cellID) and arthur)
        {
            listOfCorrect.add(lastQ)
            //     buSelected.text = "correct"
            score += 10
            printCorrect(buSelected)
            //  SystemClock.sleep(5000)
        }
        else{
            printInCorrect(buSelected)
            arthur = false
            //     buSelected.text = "InCorrect"
//                val cID = question.correctID - 1
            if (!cond)
                cond = true
            else
                {
                val cID = question.correctID
                val b = getButtonFromID(cID)
                //   b.text = "correct"
                printCorrect(b)
                    cond=false
                }
        }
     }
    fun printExit(){
        var x = listOfQuestions.size -1
        Question2.text = "Your Score is $score/$x" //+ listOfCorrect
        bu1.text ="Exit"
        bu1.setOnClickListener {
            var intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            this.finish()
        }
        bu2.visibility = View.GONE
        bu3.visibility = View.GONE
        bu4.visibility = View.GONE

    }
    fun playGame(cellID : Int, buSelected : Button){
        if (lastQ <= max){
            if (lastQ < max)
            {
                checkAndPrintCorrectIn(cellID,buSelected)
            }
            if (lastQ == max){
                if (lastQ == myList.size -1)
                    checkAndPrintCorrectIn(cellID,buSelected)
                else
                    Question2.text = "OUT OF BOUNCE"
            }
        }
        else
            printExit()

    }
//    fun playGame(cellID : Int, buSelected : Button){
//        if (lastQ < max){
//            var question = myList[lastQ]
//            if (question.isCorrect(cellID))
//            {
//                listOfCorrect.add(lastQ)
//                //     buSelected.text = "correct"
//                score += 10
//                printCorrect(buSelected)
//                //  SystemClock.sleep(5000)
//            }
//            else{
//                printInCorrect(buSelected)
//                //     buSelected.text = "InCorrect"
////                val cID = question.correctID - 1
//                val cID = question.correctID
//                val b = getButtonFromID(cID)
//                //   b.text = "correct"
//                printCorrect(b)
//            }
//        }
//        else{
//            if (lastQ==max)
//            {
//                lastQ+=1
//            }
//            else{
//            Question2.text = "Your Score is $score" //+ listOfCorrect
//            bu1.text ="Exit"
//            bu1.setOnClickListener {
//                var intent = Intent(this,MainActivity::class.java)
//                startActivity(intent)
//                this.finish()
//            }
//            bu2.visibility = View.GONE
//            bu3.visibility = View.GONE
//            bu4.visibility = View.GONE
//        }
//        }
//    }
    fun pickQuestions(num :Int): ArrayList<Question>{
        val rnd = Random()
        var loq = listOfQuestions.shuffled(rnd)
        var newList = arrayListOf<Question>()
        for (i in 0..num){
            newList.add(loq[i])
        }
        return newList
    }

    fun getDataFromJSON() : ArrayList<Question>{
        var loq = arrayListOf<Question>()
        var json : String
        try {
            var iS : InputStream = assets.open("aws.json")
            json = iS.bufferedReader().use { it.readText() }
            //  Question2.text = json
            var jsonArr = JSONArray(json)
            for (i in 0..jsonArr.length() -1)
            {
                var jsonobj = jsonArr.getJSONObject(i)
                val q = getQuestionFromJsonObject(jsonobj)
                // printQuestion(q)
                loq.add(q)
            }
        }
        catch (e : Exception)
        {
            Toast.makeText(this,"Exception", Toast.LENGTH_LONG).show()
            bu1.text = e.toString()
        }
        return loq
    }
    fun getQuestionFromJsonObject(jsonobj : JSONObject) : Question {
        val name = jsonobj.getString("Question")
      //  bu4.text = name
      //  val catr = jsonobj.getString("QuestionSubject")
        val correct = jsonobj.getInt("Answer")-1
//        bu4.text = correct.toString()
        var l = jsonobj.getJSONArray("Answers")
        var listofa = arrayListOf<Answer>()
        for (i in 0..l.length() -1){
            val s = l[i].toString()
            bu3.text = s
            val a= Answer(s)
            listofa.add(a)
        }
        //var listofab = listofa.shuffled()
        return Question(name,listofa,correct,"")
    }
    fun printQuestion(q: Question){
        arthur = true
        Question2.text = "Question # ${lastQ+1}\n" + q.question
        var listofa = q.ListOfAnswers
        bu1.text = listofa[0].answer
        bu2.text = listofa[1].answer
        bu3.text = listofa[2].answer
        bu4.text = listofa[3].answer
    }
}
