package com.example.azure.modules

class Answer(a : String) {
    val answer: String = a
    override
    fun toString(): String {
        return this.answer
    }
}